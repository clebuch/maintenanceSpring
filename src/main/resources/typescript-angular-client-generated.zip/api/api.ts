export * from './apiResourceController.service';
import { ApiResourceControllerService } from './apiResourceController.service';
export * from './openApiControllerWebMvc.service';
import { OpenApiControllerWebMvcService } from './openApiControllerWebMvc.service';
export * from './swagger2ControllerWebMvc.service';
import { Swagger2ControllerWebMvcService } from './swagger2ControllerWebMvc.service';
export * from './ticket.service';
import { TicketService } from './ticket.service';
export const APIS = [ApiResourceControllerService, OpenApiControllerWebMvcService, Swagger2ControllerWebMvcService, TicketService];
